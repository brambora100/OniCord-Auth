package cz.onicord.auth;
import com.google.gson.*;
import com.mojang.logging.LogUtils;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.protocol.game.ClientboundUpdateMobEffectPacket;
import net.minecraft.network.protocol.game.ClientboundRemoveMobEffectPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket;
import net.minecraft.network.protocol.game.ClientboundClearTitlesPacket;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;
import java.net.URI;
import java.net.http.*;
import java.nio.file.*;
import java.time.*;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

@Mod("onicordauth")
public class OniCordAuth {
 private static final Logger LOG=LogUtils.getLogger();
 private static final Gson GSON=new GsonBuilder().setPrettyPrinting().create();
 private static final SecureRandom RNG=new SecureRandom();
 private static final Set<ServerGamePacketListenerImpl> VERIFIED=ConcurrentHashMap.newKeySet();
 private final Map<ServerGamePacketListenerImpl,Pending> pending=new ConcurrentHashMap<>();
 private record Anchor(net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level> dimension,double x,double y,double z) {}
 private final Map<UUID,Anchor> anchors=new HashMap<>();
 private final AtomicBoolean busy=new AtomicBoolean();
 private final HttpClient http=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
 private ExecutorService executor;
 private volatile Config cfg;
 private static volatile OniCordAuth active;
 private final Set<ServerGamePacketListenerImpl> registrationQueued=ConcurrentHashMap.newKeySet();
 private volatile Registry registry;
 private Path registryFile;
 private static class Registry {
  Map<String,String> users=new LinkedHashMap<>();
  Set<String> reservedNames=new HashSet<>();
  Set<String> legacyUuids=new HashSet<>();
 }
 private static String key(String nick){return nick.toLowerCase(Locale.ROOT);}
 private static boolean validId(String id){return id!=null && id.matches("[0-9]{17,20}");}
 private String owner(Config c,String nick){String k=key(nick);String id=c.users.get(k);return id!=null?id:registry.users.get(k);}
 private boolean idTaken(Config c,String id,String nick){String k=key(nick);return c.users.entrySet().stream().anyMatch(e->e.getValue().equals(id)&&!e.getKey().equals(k))||registry.users.entrySet().stream().anyMatch(e->e.getValue().equals(id)&&!e.getKey().equals(k));}
 private boolean reserved(Config c,ServerPlayer p){String k=key(p.getGameProfile().getName());return c.reservedNames.contains(k)||registry.reservedNames.contains(k)||registry.legacyUuids.contains(p.getUUID().toString());}
 private void saveRegistry(Registry r)throws java.io.IOException{
  Path tmp=Files.createTempFile(registryFile.getParent(),"onicord-registry-", ".tmp");
  try { Files.writeString(tmp,GSON.toJson(r)); Files.move(tmp,registryFile,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING); }
  finally {Files.deleteIfExists(tmp);}
 }
 private Registry loadRegistry(MinecraftServer server)throws java.io.IOException{
  registryFile=FMLPaths.CONFIGDIR.get().resolve("onicord-auth-registrations.json");
  if(Files.exists(registryFile)){
   Registry r=GSON.fromJson(Files.readString(registryFile),Registry.class);
   if(r==null||r.users==null||r.reservedNames==null||r.legacyUuids==null)throw new IllegalArgumentException();
   Set<String> ids=new HashSet<>();
   for(var e:r.users.entrySet())if(!e.getKey().matches("[a-z0-9_]{3,16}")||!validId(e.getValue())||!ids.add(e.getValue()))throw new IllegalArgumentException();
   r.users=Map.copyOf(r.users);r.reservedNames=Set.copyOf(r.reservedNames);r.legacyUuids=Set.copyOf(r.legacyUuids);return r;
  }
  Registry r=new Registry();
  Path data=server.getWorldPath(net.minecraft.world.level.storage.LevelResource.PLAYER_DATA_DIR);
  if(Files.isDirectory(data))try(var paths=Files.list(data)){paths.forEach(f->{String n=f.getFileName().toString();if(n.endsWith(".dat")||n.endsWith(".dat_old")){try{r.legacyUuids.add(UUID.fromString(n.substring(0,n.indexOf('.'))).toString());}catch(IllegalArgumentException ignored){}}});}
  for(String name:server.getPlayerList().getOps().getUserList())if(name!=null)r.reservedNames.add(key(name));
  for(String name:server.getPlayerList().getWhiteListNames())if(name!=null)r.reservedNames.add(key(name));
  Path cache=Path.of("usercache.json");
  if(Files.isRegularFile(cache))for(JsonElement entry:JsonParser.parseString(Files.readString(cache)).getAsJsonArray()){
   JsonObject u=entry.getAsJsonObject();if(u.has("uuid")&&u.has("name")&&r.legacyUuids.contains(u.get("uuid").getAsString()))r.reservedNames.add(key(u.get("name").getAsString()));
  }
  saveRegistry(r);r.users=Map.copyOf(r.users);r.reservedNames=Set.copyOf(r.reservedNames);r.legacyUuids=Set.copyOf(r.legacyUuids);return r;
 }
 private boolean register(Config c,Pending q,String id){
  if(!c.allowNewRegistrations||reserved(c,q.connection.player)||q.connection.player.getServer().getPlayerList().isOp(q.connection.player.getGameProfile())||owner(c,q.nick)!=null||idTaken(c,id,q.nick))return false;
  Registry next=new Registry();next.users.putAll(registry.users);next.users.put(key(q.nick),id);next.reservedNames.addAll(registry.reservedNames);next.legacyUuids.addAll(registry.legacyUuids);
  try{saveRegistry(next);next.users=Map.copyOf(next.users);next.reservedNames=Set.copyOf(next.reservedNames);next.legacyUuids=Set.copyOf(next.legacyUuids);registry=next;LOG.info("OniCord Auth: registered {}",q.nick);return true;}
  catch(Exception e){LOG.error("OniCord Auth: registry write failed ({})",e.getClass().getSimpleName());return false;}
 }
 private static void registrationScreen(Pending q){
  ServerPlayer p=q.connection.player;fog(p);overlay(q);countdown(q);
  p.sendSystemMessage(label("NOVÁ REGISTRACE",ChatFormatting.WHITE));
  p.sendSystemMessage(Component.literal("Na Discordu zapni Vývojářský režim a zkopíruj ID svého uživatele (ne nick). Pak v Minecraftu napiš:").withStyle(ChatFormatting.GRAY));
  p.sendSystemMessage(Component.literal("/oniauth register TVOJE_DISCORD_ID").withStyle(ChatFormatting.AQUA));
  p.sendSystemMessage(Component.literal("Poté dostaneš kód do ověřovací místnosti. Pro změnu ID se znovu připoj.").withStyle(ChatFormatting.YELLOW));
 }
 // The mixin consumes only this narrow command; it never runs through the OP command dispatcher.
 public static boolean registrationCommand(ServerGamePacketListenerImpl connection,String command){
  if(!command.matches("oniauth register [0-9]{17,20}"))return false;
  OniCordAuth self=active;MinecraftServer server=connection.player.getServer();
  if(self!=null&&server!=null){Pending q=self.pending.get(connection);if(q!=null&&q.registration&&q.discord.isEmpty()&&self.registrationQueued.add(connection))server.execute(()->{try{self.chooseId(connection,command.substring("oniauth register ".length()));}finally{self.registrationQueued.remove(connection);}});}
  return true;
 }
 private void chooseId(ServerGamePacketListenerImpl connection,String id){
  Config c=cfg;Pending old=pending.get(connection);
  if(c==null||old==null||!old.discord.isEmpty()||!old.registration||System.currentTimeMillis()>=old.expires)return;
  if(!c.allowNewRegistrations||reserved(c,connection.player)||owner(c,old.nick)!=null||idTaken(c,id,old.nick)){
   connection.player.sendSystemMessage(label("Registrace není povolena nebo Discord účet již patří jinému nicku.",ChatFormatting.RED));return;
  }
  Pending q=new Pending(connection,old.nick,id,newCode(),System.currentTimeMillis()+600000,Instant.now(),true);
  if(pending.replace(connection,old,q))show(q,c);
 }
 private String newCode(){String code;boolean collision;do{code=String.format(Locale.ROOT,"%08d",RNG.nextInt(100000000));collision=false;for(Pending q:pending.values())if(q.code.equals(code)){collision=true;break;}}while(collision);return code;}

 private int ticks;
 private volatile long retryAfter=0;
 private volatile long lastWarning=0;
 private final Map<String,Long> handled=new ConcurrentHashMap<>();
 private static Component label(String text,ChatFormatting color){return Component.empty().append(Component.literal("ONICORD ").withStyle(ChatFormatting.AQUA,ChatFormatting.BOLD)).append(Component.literal("| ").withStyle(ChatFormatting.DARK_GRAY)).append(Component.literal(text).withStyle(color));}
 // Visual effects are sent only to this connection. No effects are added to
 // persistent player data, and existing real effects are restored on success.
 private static void fog(ServerPlayer p){
  for(MobEffect effect:List.of(MobEffects.BLINDNESS,MobEffects.DARKNESS))
   p.connection.send(new ClientboundUpdateMobEffectPacket(p.getId(),new MobEffectInstance(effect,1200,0,false,false,false)));
 }
 private static void restoreVision(ServerPlayer p){
  for(MobEffect effect:List.of(MobEffects.BLINDNESS,MobEffects.DARKNESS)){
   p.connection.send(new ClientboundRemoveMobEffectPacket(p.getId(),effect));
   MobEffectInstance real=p.getEffect(effect);
   if(real!=null)p.connection.send(new ClientboundUpdateMobEffectPacket(p.getId(),real));
  }
 }
 private static void overlay(Pending q){
  var c=q.connection;
  c.send(new ClientboundSetTitlesAnimationPacket(0,120,0));
  c.send(new ClientboundSetSubtitleTextPacket(q.code.isEmpty()?Component.literal("Zadej /oniauth register + Discord ID").withStyle(ChatFormatting.YELLOW):Component.literal("@OniCord ").withStyle(ChatFormatting.AQUA).append(Component.literal(q.code).withStyle(ChatFormatting.GREEN,ChatFormatting.BOLD))));
  c.send(new ClientboundSetTitleTextPacket(Component.literal(q.code.isEmpty()?"NOVÁ REGISTRACE":"OVĚŘENÍ ÚČTU").withStyle(ChatFormatting.AQUA,ChatFormatting.BOLD)));
 }
 private static void countdown(Pending q){
  long remaining=Math.max(0,(q.expires-System.currentTimeMillis()+999)/1000);
  String time=String.format(Locale.ROOT,"%02d:%02d",remaining/60,remaining%60);
  q.connection.send(new ClientboundSetActionBarTextPacket(Component.literal("Čekáme na Discord  |  ").withStyle(ChatFormatting.GRAY).append(Component.literal(time).withStyle(ChatFormatting.YELLOW)).append(Component.literal("  |  Hraní uzamčeno").withStyle(ChatFormatting.RED))));
 }
 private static void show(Pending q,Config config){
  ServerPlayer p=q.connection.player;
  fog(p); overlay(q); countdown(q);
  p.sendSystemMessage(label("OVĚŘENÍ ÚČTU",ChatFormatting.WHITE));
  p.sendSystemMessage(Component.literal("Otevři ověřovací místnost na Discordu").withStyle(style->style.withColor(ChatFormatting.AQUA).withUnderlined(true).withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL,"https://discord.com/channels/"+config.guildId+"/"+config.channelId))));
  p.sendSystemMessage(Component.literal("Označ skutečného bota a napiš tento kód:").withStyle(ChatFormatting.GRAY));
  p.sendSystemMessage(Component.literal("@OniCord ").withStyle(ChatFormatting.AQUA).append(Component.literal(q.code).withStyle(ChatFormatting.GREEN,ChatFormatting.BOLD)));
  p.sendSystemMessage(Component.literal("Kód platí 10 minut. Po ověření tě automaticky pustíme do hry.").withStyle(ChatFormatting.YELLOW));
 }
 private static void successScreen(ServerPlayer p){
  restoreVision(p);
  p.connection.send(new ClientboundClearTitlesPacket(true));
  p.connection.send(new ClientboundSetActionBarTextPacket(Component.empty()));
  p.connection.send(new ClientboundSetTitlesAnimationPacket(5,55,15));
  p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal("Vítej na OniCordu!").withStyle(ChatFormatting.WHITE)));
  p.connection.send(new ClientboundSetTitleTextPacket(Component.literal("OVĚŘENO").withStyle(ChatFormatting.GREEN,ChatFormatting.BOLD)));
 }
 private record Pending(ServerGamePacketListenerImpl connection,String nick,String discord,String code,long expires,Instant created,boolean registration) {}
 private static class Config {
  String botToken="CHANGE_ME", guildId="CHANGE_ME", channelId="CHANGE_ME", botId="CHANGE_ME", requiredRoleId="1415584931232481380";
  Map<String,String> users=new LinkedHashMap<>();
  boolean allowNewRegistrations=true;
  Set<String> reservedNames=new HashSet<>();
  Set<String> operators=new HashSet<>();
 }
 public OniCordAuth(){ MinecraftForge.EVENT_BUS.register(this); }
 public static boolean allowed(ServerGamePacketListenerImpl listener){return VERIFIED.contains(listener);}
 @SubscribeEvent public void start(ServerStartingEvent event){
  active=this; registry=null; registrationQueued.clear(); VERIFIED.clear(); pending.clear(); anchors.clear(); handled.clear(); retryAfter=0; lastWarning=0; ticks=0; busy.set(false); executor=Executors.newSingleThreadExecutor();
  Path file=FMLPaths.CONFIGDIR.get().resolve("onicord-auth.json");
  try {
   if(Files.notExists(file)){ Config example=new Config(); example.users.put("tickony","CHANGE_ME"); Files.writeString(file,GSON.toJson(example)); }
   Config c=GSON.fromJson(Files.readString(file),Config.class);
   if(c==null || c.botToken==null || c.botToken.equals("CHANGE_ME") || c.botToken.isBlank()) throw new IllegalArgumentException();
   for(String s:List.of(c.guildId,c.channelId,c.botId,c.requiredRoleId)) if(!s.matches("[0-9]{17,20}")) throw new IllegalArgumentException();
   Map<String,String> clean=new HashMap<>(); Set<String> ids=new HashSet<>();
   for(var e:c.users.entrySet()){
    if(!e.getKey().matches("[A-Za-z0-9_]{3,16}") || !e.getValue().matches("[0-9]{17,20}") || !ids.add(e.getValue()) || clean.put(e.getKey().toLowerCase(Locale.ROOT),e.getValue())!=null) throw new IllegalArgumentException();
   }
   c.users=Map.copyOf(clean);
   // Only manually linked accounts may be granted operator status.
   Set<String> operators=new HashSet<>();
   for(String name:c.operators){
    if(name==null||!name.matches("[A-Za-z0-9_]{3,16}")||!c.users.containsKey(key(name)))throw new IllegalArgumentException("operators must be manually linked in users");
    operators.add(key(name));
   }
   c.operators=Set.copyOf(operators);
   Set<String> reserved=new HashSet<>();for(String name:c.reservedNames){if(!name.matches("[A-Za-z0-9_]{3,16}"))throw new IllegalArgumentException();reserved.add(key(name));}c.reservedNames=Set.copyOf(reserved);
   registry=loadRegistry(event.getServer());
   for(var e:registry.users.entrySet())if((c.users.containsKey(e.getKey())&&!c.users.get(e.getKey()).equals(e.getValue()))||idTaken(c,e.getValue(),e.getKey()))throw new IllegalArgumentException();
   // Remove stale grants for managed accounts after a crash/restart, before players join.
   var players=event.getServer().getPlayerList();
   // StoredUserEntry#getUser is package-private in Minecraft 1.20.1.
   // Read the persisted operator profiles instead of guessing offline UUIDs.
   var ops=players.getOps();
   if(!ops.isEmpty()){
    Path opsFile=ops.getFile().toPath();
    var entries=JsonParser.parseString(Files.readString(opsFile)).getAsJsonArray();
    for(JsonElement entry:entries){
     JsonObject obj=entry.getAsJsonObject();
     if(!obj.has("name")||!obj.has("uuid"))continue;
     String name=obj.get("name").getAsString();
     if(!c.operators.contains(key(name)))continue;
     UUID uuid=UUID.fromString(obj.get("uuid").getAsString());
     var profile=new com.mojang.authlib.GameProfile(uuid,name);
     players.deop(profile);
    }
   }
   cfg=c; LOG.info("OniCord Auth: loaded {} manual and {} self-service accounts; {} configured operators",clean.size(),registry.users.size(),c.operators.size());
  }catch(Exception e){cfg=null; LOG.error("OniCord Auth: invalid config; player access disabled. Check config/onicord-auth.json");}
 }
 @SubscribeEvent public void stop(ServerStoppingEvent event){
  cfg=null; active=null; VERIFIED.clear(); pending.clear(); anchors.clear();
  var players=event.getServer().getPlayerList();
  for(ServerPlayer p:new ArrayList<>(players.getPlayers()))if(players.isOp(p.getGameProfile()))players.deop(p.getGameProfile());
  if(executor!=null)executor.shutdownNow();
 }
 @SubscribeEvent public void join(PlayerEvent.PlayerLoggedInEvent event){
  if(!(event.getEntity() instanceof ServerPlayer p))return;
  var connection=p.connection; VERIFIED.remove(connection); Config c=cfg;
  anchors.put(p.getUUID(),new Anchor(p.level().dimension(),p.getX(),p.getY(),p.getZ()));
  boolean wasOp=p.getServer().getPlayerList().isOp(p.getGameProfile());
  if(wasOp)p.getServer().getPlayerList().deop(p.getGameProfile());
  String nick=p.getGameProfile().getName();
  if(c==null||!nick.matches("[A-Za-z0-9_]{3,16}")){connection.disconnect(Component.literal("OniCord: ověřování není dostupné."));return;}
  String id=owner(c,nick);
  if(id==null){
   if(wasOp||!c.allowNewRegistrations||reserved(c,p)){connection.disconnect(Component.literal("OniCord: tento účet musí nejdříve propojit administrátor."));return;}
   Pending q=new Pending(connection,nick,"","",System.currentTimeMillis()+600000,Instant.now(),true);pending.put(connection,q);registrationScreen(q);return;
  }
  Pending q=new Pending(connection,nick,id,newCode(),System.currentTimeMillis()+600000,Instant.now(),false);pending.put(connection,q);
  show(q,c); LOG.info("OniCord Auth: waiting for Discord verification of {}",nick);
 }
 @SubscribeEvent public void leave(PlayerEvent.PlayerLoggedOutEvent event){if(event.getEntity() instanceof ServerPlayer p){VERIFIED.remove(p.connection);pending.remove(p.connection);anchors.remove(p.getUUID()); if(p.getServer().getPlayerList().isOp(p.getGameProfile()))p.getServer().getPlayerList().deop(p.getGameProfile());}}
 @SubscribeEvent public void tick(TickEvent.ServerTickEvent event){
  if(event.phase!=TickEvent.Phase.END)return;
  for(ServerPlayer p:event.getServer().getPlayerList().getPlayers()){
   if(allowed(p.connection))continue;
   // Also revoke a manual OP grant made while authentication is pending.
   var players=event.getServer().getPlayerList();
   if(players.isOp(p.getGameProfile()))players.deop(p.getGameProfile());
   Anchor a=anchors.get(p.getUUID());
   if(a==null)continue;
   Pending q=pending.get(p.connection);
   if(q!=null){
    if(p.tickCount%80==0)overlay(q);
    if(p.tickCount%100==0)fog(p);
    if(p.tickCount%20==0)countdown(q);
   }
   p.stopRiding(); p.setDeltaMovement(0,0,0); p.fallDistance=0;
   if(!p.level().dimension().equals(a.dimension())){p.connection.disconnect(Component.literal("OniCord: změna dimenze před ověřením."));continue;}
   if(p.distanceToSqr(a.x(),a.y(),a.z())>0.000001 || p.tickCount%10==0)
    p.connection.teleport(a.x(),a.y(),a.z(),p.getYRot(),p.getXRot());
  }
  for(Pending q:pending.values()) if(System.currentTimeMillis()>=q.expires && pending.remove(q.connection,q))q.connection.disconnect(Component.literal("OniCord: ověření vypršelo. Připoj se znovu."));
  if(++ticks%60!=0 || System.currentTimeMillis()<retryAfter || pending.values().stream().noneMatch(q->!q.code.isEmpty()) || cfg==null || !busy.compareAndSet(false,true))return;
  Config c=cfg; MinecraftServer server=event.getServer();
  executor.execute(()->{try{poll(c,server);}catch(Exception e){if(System.currentTimeMillis()-lastWarning>15000){lastWarning=System.currentTimeMillis(); LOG.warn("OniCord Auth: Discord verification unavailable ({})",e.getClass().getSimpleName());}}finally{busy.set(false);}});
 }
 private static boolean locked(net.minecraft.world.entity.Entity e){return e instanceof ServerPlayer p && !allowed(p.connection);}
 @SubscribeEvent(priority=net.minecraftforge.eventbus.api.EventPriority.HIGHEST) public void protectWaitingPlayer(net.minecraftforge.event.entity.living.LivingAttackEvent e){if(locked(e.getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void breakBlock(net.minecraftforge.event.level.BlockEvent.BreakEvent e){if(locked(e.getPlayer()))e.setCanceled(true);}
 @SubscribeEvent public void placeBlock(net.minecraftforge.event.level.BlockEvent.EntityPlaceEvent e){if(locked(e.getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void attack(net.minecraftforge.event.entity.player.AttackEntityEvent e){if(locked(e.getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void rightBlock(net.minecraftforge.event.entity.player.PlayerInteractEvent.RightClickBlock e){if(locked(e.getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void rightItem(net.minecraftforge.event.entity.player.PlayerInteractEvent.RightClickItem e){if(locked(e.getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void leftBlock(net.minecraftforge.event.entity.player.PlayerInteractEvent.LeftClickBlock e){if(locked(e.getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void interact(net.minecraftforge.event.entity.player.PlayerInteractEvent.EntityInteract e){if(locked(e.getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void interactSpecific(net.minecraftforge.event.entity.player.PlayerInteractEvent.EntityInteractSpecific e){if(locked(e.getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void chat(net.minecraftforge.event.ServerChatEvent e){if(locked(e.getPlayer()))e.setCanceled(true);}
 @SubscribeEvent public void command(net.minecraftforge.event.CommandEvent e){if(locked(e.getParseResults().getContext().getSource().getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void pickup(net.minecraftforge.event.entity.player.EntityItemPickupEvent e){if(locked(e.getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void toss(net.minecraftforge.event.entity.item.ItemTossEvent e){if(locked(e.getPlayer())){e.setCanceled(true); e.getPlayer().getInventory().add(e.getEntity().getItem());}}
 private HttpResponse<String> request(Config c,String method,String path)throws Exception{return request(c,method,path,null);}
 private HttpResponse<String> request(Config c,String method,String path,String body)throws Exception{
  var builder=HttpRequest.newBuilder(URI.create("https://discord.com/api/v10"+path)).header("Authorization","Bot "+c.botToken).header("User-Agent","DiscordBot (https://onicord.pro, 0.7.1)").timeout(Duration.ofSeconds(10));
  if(body!=null)builder.header("Content-Type","application/json");
  var result=http.send(builder.method(method,body==null?HttpRequest.BodyPublishers.noBody():HttpRequest.BodyPublishers.ofString(body)).build(),HttpResponse.BodyHandlers.ofString());
  if(result.statusCode()==429){double seconds=5; try{seconds=JsonParser.parseString(result.body()).getAsJsonObject().get("retry_after").getAsDouble();}catch(Exception ignored){} retryAfter=System.currentTimeMillis()+Math.max(1000,(long)(seconds*1000)+500); LOG.warn("OniCord Auth: Discord rate limit; retry scheduled");}
  return result;
 }
 private void feedback(Config c,MinecraftServer server,Pending q,String message){
  server.execute(()->{if(pending.get(q.connection)==q)q.connection.player.sendSystemMessage(label(message,ChatFormatting.RED));});
 }
 // Never send verification feedback to a public channel. DMs are optional;
 // a blocked DM must not prevent authentication or cleanup of used codes.
 private void replyPrivate(Config c,String discordId,String message){
  if(System.currentTimeMillis()<retryAfter)return;
  try{
   JsonObject recipient=new JsonObject();recipient.addProperty("recipient_id",discordId);
   var dm=request(c,"POST","/users/@me/channels",recipient.toString());
   if(dm.statusCode()!=200 && dm.statusCode()!=201){LOG.debug("OniCord Auth: DM channel unavailable (HTTP {})",dm.statusCode());return;}
   String channel=JsonParser.parseString(dm.body()).getAsJsonObject().get("id").getAsString();
   if(!channel.matches("[0-9]{17,20}") || channel.equals(c.channelId))return;
   if(System.currentTimeMillis()<retryAfter)return;
   JsonObject body=new JsonObject();body.addProperty("content",message);
   JsonObject mentions=new JsonObject();mentions.add("parse",new JsonArray());body.add("allowed_mentions",mentions);
   var r=request(c,"POST","/channels/"+channel+"/messages",body.toString());
   if(r.statusCode()!=200 && r.statusCode()!=201)LOG.debug("OniCord Auth: DM unavailable (HTTP {})",r.statusCode());
  }catch(InterruptedException e){Thread.currentThread().interrupt();}
  catch(Exception e){LOG.debug("OniCord Auth: optional DM unavailable ({})",e.getClass().getSimpleName());}
 }
 private void poll(Config c,MinecraftServer server)throws Exception{
  long now=System.currentTimeMillis(); handled.entrySet().removeIf(e->e.getValue()<now-900000);
  Instant earliest=pending.values().stream().map(Pending::created).min(Instant::compareTo).orElse(Instant.now()).minusSeconds(10);
  String before="";
  for(int page=0;page<10 && !pending.isEmpty();page++){
   if(System.currentTimeMillis()<retryAfter)return;
   var response=request(c,"GET","/channels/"+c.channelId+"/messages?limit=100"+(before.isEmpty()?"":"&before="+before));
   if(response.statusCode()!=200){if(now-lastWarning>15000){lastWarning=now;LOG.warn("OniCord Auth: reading verification channel HTTP {} (401 token, 403 permissions, 404 channel)",response.statusCode());}return;}
   JsonArray messages=JsonParser.parseString(response.body()).getAsJsonArray();
   if(messages.isEmpty())return;
   boolean old=false;
   for(JsonElement entry:messages){
    if(System.currentTimeMillis()<retryAfter)return;
    JsonObject m=entry.getAsJsonObject(); String mid=m.get("id").getAsString(); before=mid;
    Instant sent=OffsetDateTime.parse(m.get("timestamp").getAsString()).toInstant(); if(sent.isBefore(earliest)){old=true;continue;}
    if(handled.containsKey(mid))continue;
    JsonObject author=m.getAsJsonObject("author"); if(author.has("bot")&&author.get("bot").getAsBoolean())continue;
    String id=author.get("id").getAsString(); String body=m.has("content")?m.get("content").getAsString().trim():"";
    // Accept real Discord mentions, including the legacy nickname mention syntax.
    String prefix="<@"+c.botId+">", alt="<@!"+c.botId+">";
    boolean mention=body.startsWith(prefix)||body.startsWith(alt);
    String code=mention?body.substring(body.indexOf('>')+1).trim():"";
    Pending own=pending.values().stream().filter(q->q.discord.equals(id)&&!q.code.isEmpty()&&q.code.equals(code)).findFirst().orElse(null);
    Pending forId=pending.values().stream().filter(q->q.discord.equals(id)&&!q.code.isEmpty()).findFirst().orElse(null);
    if(!mention){if(forId!=null && body.matches("[0-9]{8}")){handled.put(mid,now);feedback(c,server,forId,"Označ skutečného bota @OniCord před kódem.");replyPrivate(c,id,"Označ @OniCord a přidej svůj ověřovací kód.");}continue;}
    if(own==null){handled.put(mid,now);if(forId!=null){feedback(c,server,forId,"Kód nesouhlasí. Použij aktuální kód z Minecraftu.");replyPrivate(c,id,"Kód nesouhlasí. Použij aktuální kód z Minecraftu.");}continue;}
    if(!code.matches("[0-9]{8}") || !own.code.equals(code) || sent.isBefore(own.created.minusSeconds(10)) || System.currentTimeMillis()>=own.expires){handled.put(mid,now);feedback(c,server,own,"Kód nesouhlasí nebo vypršel. Použij aktuální kód z Minecraftu.");replyPrivate(c,id,"Kód nesouhlasí nebo vypršel. Použij aktuální kód z Minecraftu.");continue;}
    var member=request(c,"GET","/guilds/"+c.guildId+"/members/"+id);
    if(member.statusCode()!=200){LOG.warn("OniCord Auth: membership lookup for {} HTTP {}",own.nick,member.statusCode()); if(member.statusCode()==404){handled.put(mid,now);feedback(c,server,own,"Discord účet není členem serveru.");replyPrivate(c,id,"Nejsi členem požadovaného Discord serveru.");}else if(member.statusCode()!=429){feedback(c,server,own,"Discord API neodpovědělo správně (HTTP "+member.statusCode()+"). Kontaktuj admina.");}continue;}
    boolean role=false; for(JsonElement r:JsonParser.parseString(member.body()).getAsJsonObject().getAsJsonArray("roles"))if(r.getAsString().equals(c.requiredRoleId))role=true;
    if(!role){handled.put(mid,now);LOG.info("OniCord Auth: required role missing for {}",own.nick);feedback(c,server,own,"Chybí požadovaná Discord role.");replyPrivate(c,id,"Chybí požadovaná role. Po získání role odešli kód znovu.");continue;}
    handled.put(mid,now);
    CompletableFuture<Boolean> accepted=new CompletableFuture<>();
    server.execute(()->{
     if(cfg!=c||System.currentTimeMillis()>=own.expires||pending.get(own.connection)!=own){accepted.complete(false);return;}
     if(own.registration){if(!register(c,own,id)){own.connection.player.sendSystemMessage(label("Registraci nelze uložit, nick je rezervovaný nebo Discord ID již má účet. Kontaktuj admina.",ChatFormatting.RED));accepted.complete(false);return;}}
     else if(!id.equals(owner(c,own.nick))){accepted.complete(false);return;}
     ServerPlayer player=own.connection.player;
     var players=server.getPlayerList();
     if(players.getPlayer(player.getUUID())!=player || player.connection!=own.connection){accepted.complete(false);return;}
     pending.remove(own.connection,own); VERIFIED.add(own.connection); anchors.remove(player.getUUID());
     successScreen(player);
     player.sendSystemMessage(label(own.registration?"Registrace dokončena! Vítej na OniCordu.":"Úspěšně ověřeno! Vítej na OniCordu.",ChatFormatting.GREEN));
     // Never use a self-service registration or the Discord role alone as authority for OP.
     String nickKey=key(own.nick);
     if(!own.registration && c.operators.contains(nickKey) && id.equals(c.users.get(nickKey)) && key(player.getGameProfile().getName()).equals(nickKey)){
      try{
       players.op(player.getGameProfile());
       if(players.isOp(player.getGameProfile())){
        player.sendSystemMessage(label("Administrátorská oprávnění (OP) obnovena.",ChatFormatting.AQUA));
        LOG.info("OniCord Auth: OP granted to verified configured operator {}",own.nick);
       }else{player.sendSystemMessage(label("OP se nepodařilo obnovit. Kontaktuj správce.",ChatFormatting.RED));LOG.warn("OniCord Auth: OP grant not confirmed for {}",own.nick);}
      }catch(RuntimeException e){
       LOG.error("OniCord Auth: OP grant failed for {} ({})",own.nick,e.getClass().getSimpleName());
       player.sendSystemMessage(label("OP se nepodařilo obnovit. Kontaktuj správce.",ChatFormatting.RED));
      }
     }
     LOG.info("OniCord Auth: verified {}",own.nick); accepted.complete(true);
    });
    if(accepted.get(10,TimeUnit.SECONDS)){
     try{if(System.currentTimeMillis()>=retryAfter){var deletion=request(c,"DELETE","/channels/"+c.channelId+"/messages/"+mid);if(deletion.statusCode()!=204 && deletion.statusCode()!=404)LOG.warn("OniCord Auth: message deletion HTTP {}",deletion.statusCode());}}
     catch(InterruptedException e){Thread.currentThread().interrupt();return;}
     catch(Exception e){LOG.warn("OniCord Auth: used code deletion unavailable ({})",e.getClass().getSimpleName());}
     replyPrivate(c,id,"✅ Ověření proběhlo úspěšně. Můžeš hrát!");
    }
   }
   if(old||messages.size()<100)return;
  }
 }
}
