package cz.onicord.auth;
public class VerificationCodeTest {
 public static void main(String[] args){
  String id="123456789012345678", code="01234567";
  String[] good={code,"  "+code+"  ","@OniCord"+code,"@OniCord "+code,"@OniCord  "+code,"@onicord\u00a0"+code,"<@"+id+">"+code,"<@!"+id+">  "+code,"<@"+id+">\n"+code,"0123 4567"};
  String[] bad={"hello", "@OniCord", "hi "+code, code+" hi", "<@999999999999999999> "+code, "@other "+code, "1234567", "123456789", "12345678 87654321", "https://example.com/"+code, "", "１２３４５６７８"};
  for(String s:good)if(!code.equals(VerificationCode.parse(s,id)))throw new AssertionError("valid format rejected: "+s);
  for(String s:bad)if(VerificationCode.parse(s,id)!=null)throw new AssertionError("invalid format accepted: "+s);
  System.out.println("PASS "+(good.length+bad.length)+" parser cases");
 }
}
