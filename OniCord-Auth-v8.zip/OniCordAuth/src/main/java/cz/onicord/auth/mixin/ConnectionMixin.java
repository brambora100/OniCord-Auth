package cz.onicord.auth.mixin;
import cz.onicord.auth.OniCordAuth;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundKeepAlivePacket;
import net.minecraft.network.protocol.game.ServerboundChatCommandPacket;
import net.minecraft.network.protocol.game.ServerboundAcceptTeleportationPacket;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Connection.class)
public abstract class ConnectionMixin {
 @Shadow private volatile PacketListener packetListener;
 @Inject(method="channelRead0(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/protocol/Packet;)V", at=@At("HEAD"), cancellable=true, remap=false)
 private void oni$guard(ChannelHandlerContext ctx, Packet<?> packet, CallbackInfo ci) {
  if (packetListener instanceof ServerGamePacketListenerImpl listener && !OniCordAuth.allowed(listener)
      && !(packet instanceof ServerboundKeepAlivePacket) && !(packet instanceof ServerboundAcceptTeleportationPacket)) {
   if(packet instanceof ServerboundChatCommandPacket cmd)OniCordAuth.registrationCommand(listener,cmd.command());
   ci.cancel();
  }
 }
}
