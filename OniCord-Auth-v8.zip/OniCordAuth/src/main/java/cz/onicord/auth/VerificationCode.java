package cz.onicord.auth;
import java.util.regex.Pattern;
final class VerificationCode {
 private static final Pattern SPACE=Pattern.compile("[\\p{Z}\\s]+",Pattern.UNICODE_CHARACTER_CLASS);
 static String parse(String body,String botId){
  if(body==null||botId==null)return null;
  String text=SPACE.matcher(body).replaceAll("").strip();
  String direct="<@"+botId+">", legacy="<@!"+botId+">";
  if(text.startsWith(direct))text=text.substring(direct.length());
  else if(text.startsWith(legacy))text=text.substring(legacy.length());
  else if(text.regionMatches(true,0,"@OniCord",0,8))text=text.substring(8);
  return text.matches("[0-9]{8}")?text:null;
 }
}
