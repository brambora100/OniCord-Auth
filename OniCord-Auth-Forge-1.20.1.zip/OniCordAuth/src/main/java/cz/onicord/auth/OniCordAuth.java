package cz.onicord.auth;
import com.google.gson.*;
import com.mojang.logging.LogUtils;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;
import java.net.URI;
import java.net.http.*;
import java.nio.file.*;
import java.time.*;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

@Mod("onicordauth")
public class OniCordAuth {
 private static final Logger LOG=LogUtils.getLogger();
 private static final Gson GSON=new GsonBuilder().setPrettyPrinting().create();
 private static final SecureRandom RNG=new SecureRandom();
 private static final Set<ServerGamePacketListenerImpl> VERIFIED=ConcurrentHashMap.newKeySet();
 private final Map<ServerGamePacketListenerImpl,Pending> pending=new ConcurrentHashMap<>();
 private final AtomicBoolean busy=new AtomicBoolean();
 private final HttpClient http=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
 private ExecutorService executor;
 private volatile Config cfg;
 private int ticks;
 private record Pending(ServerGamePacketListenerImpl connection,String nick,String discord,String code,long expires,Instant created) {}
 private static class Config {
  String botToken="CHANGE_ME", guildId="CHANGE_ME", channelId="CHANGE_ME", botId="CHANGE_ME", requiredRoleId="1415584931232481380";
  Map<String,String> users=new LinkedHashMap<>();
 }
 public OniCordAuth(){ MinecraftForge.EVENT_BUS.register(this); }
 public static boolean allowed(ServerGamePacketListenerImpl listener){return VERIFIED.contains(listener);}
 @SubscribeEvent public void start(ServerStartingEvent event){
  VERIFIED.clear(); pending.clear(); ticks=0; busy.set(false); executor=Executors.newSingleThreadExecutor();
  Path file=FMLPaths.CONFIGDIR.get().resolve("onicord-auth.json");
  try {
   if(Files.notExists(file)){ Config example=new Config(); example.users.put("tickony","CHANGE_ME"); Files.writeString(file,GSON.toJson(example)); }
   Config c=GSON.fromJson(Files.readString(file),Config.class);
   if(c==null || c.botToken==null || c.botToken.equals("CHANGE_ME") || c.botToken.isBlank()) throw new IllegalArgumentException();
   for(String s:List.of(c.guildId,c.channelId,c.botId,c.requiredRoleId)) if(!s.matches("[0-9]{17,20}")) throw new IllegalArgumentException();
   Map<String,String> clean=new HashMap<>(); Set<String> ids=new HashSet<>();
   for(var e:c.users.entrySet()){
    if(!e.getKey().matches("[A-Za-z0-9_]{3,16}") || !e.getValue().matches("[0-9]{17,20}") || !ids.add(e.getValue()) || clean.put(e.getKey().toLowerCase(Locale.ROOT),e.getValue())!=null) throw new IllegalArgumentException();
   }
   c.users=Map.copyOf(clean); cfg=c; LOG.info("OniCord Auth: loaded {} linked accounts",clean.size());
  }catch(Exception e){cfg=null; LOG.error("OniCord Auth: invalid config; player access disabled. Check config/onicord-auth.json");}
 }
 @SubscribeEvent public void stop(ServerStoppingEvent event){cfg=null; VERIFIED.clear(); pending.clear(); if(executor!=null)executor.shutdownNow();}
 @SubscribeEvent public void join(PlayerEvent.PlayerLoggedInEvent event){
  if(!(event.getEntity() instanceof ServerPlayer p))return;
  var connection=p.connection; VERIFIED.remove(connection); Config c=cfg;
  String nick=p.getGameProfile().getName(); String id=c==null?null:c.users.get(nick.toLowerCase(Locale.ROOT));
  if(id==null){connection.disconnect(Component.literal("OniCord: účet není propojen s Discordem. Kontaktuj administrátora."));return;}
  // Avoid using an unauthenticated player's operator permissions, including after a restart.
  if(p.getServer().getPlayerList().isOp(p.getGameProfile())) {p.getServer().getPlayerList().deop(p.getGameProfile());}
  String code; boolean collision; do {code=String.format(Locale.ROOT,"%08d",RNG.nextInt(100000000)); collision=false; for(Pending q:pending.values())if(q.code.equals(code)){collision=true;break;}}while(collision);
  Pending q=new Pending(connection,nick,id,code,System.currentTimeMillis()+300000,Instant.now()); pending.put(connection,q);
  p.sendSystemMessage(Component.literal("OniCord Auth: ověření vyžadováno. V Discord místnosti napiš @bot "+code+". Kód platí 5 minut. Nikomu ho neposílej."));
 }
 @SubscribeEvent public void leave(PlayerEvent.PlayerLoggedOutEvent event){if(event.getEntity() instanceof ServerPlayer p){VERIFIED.remove(p.connection);pending.remove(p.connection); if(p.getServer().getPlayerList().isOp(p.getGameProfile()))p.getServer().getPlayerList().deop(p.getGameProfile());}}
 @SubscribeEvent public void tick(TickEvent.ServerTickEvent event){
  if(event.phase!=TickEvent.Phase.END)return;
  for(Pending q:pending.values()) if(System.currentTimeMillis()>=q.expires && pending.remove(q.connection,q))q.connection.disconnect(Component.literal("OniCord: ověření vypršelo. Připoj se znovu."));
  if(++ticks%60!=0 || pending.isEmpty() || cfg==null || !busy.compareAndSet(false,true))return;
  Config c=cfg; MinecraftServer server=event.getServer();
  executor.execute(()->{try{poll(c,server);}catch(Exception e){LOG.warn("OniCord Auth: Discord verification unavailable ({}).",e.getClass().getSimpleName());}finally{busy.set(false);}});
 }
 private HttpResponse<String> request(Config c,String method,String path)throws Exception{
  var builder=HttpRequest.newBuilder(URI.create("https://discord.com/api/v10"+path)).header("Authorization","Bot "+c.botToken).header("User-Agent","DiscordBot (https://onicord.pro, 0.1.0)").timeout(Duration.ofSeconds(10));
  return http.send(builder.method(method,HttpRequest.BodyPublishers.noBody()).build(),HttpResponse.BodyHandlers.ofString());
 }
 private void poll(Config c,MinecraftServer server)throws Exception{
  var response=request(c,"GET","/channels/"+c.channelId+"/messages?limit=50"); if(response.statusCode()!=200)throw new IllegalStateException("Discord HTTP "+response.statusCode());
  JsonArray messages=JsonParser.parseString(response.body()).getAsJsonArray();
  for(JsonElement entry:messages){JsonObject m=entry.getAsJsonObject(); JsonObject author=m.getAsJsonObject("author"); if(author.has("bot")&&author.get("bot").getAsBoolean())continue;
   String body=m.get("content").getAsString().trim(); String prefix="<@"+c.botId+">"; String alt="<@!"+c.botId+">";
   if(body.startsWith(prefix))body=body.substring(prefix.length()).trim(); else if(body.startsWith(alt))body=body.substring(alt.length()).trim(); else continue;
   if(!body.matches("[0-9]{8}"))continue;
   String id=author.get("id").getAsString(); Instant sent=OffsetDateTime.parse(m.get("timestamp").getAsString()).toInstant();
   for(Pending q:pending.values()){
    if(!q.discord.equals(id)||!q.code.equals(body)||sent.isBefore(q.created)||System.currentTimeMillis()>=q.expires)continue;
    var member=request(c,"GET","/guilds/"+c.guildId+"/members/"+id); if(member.statusCode()!=200)continue;
    boolean role=false; for(JsonElement r:JsonParser.parseString(member.body()).getAsJsonObject().getAsJsonArray("roles"))if(r.getAsString().equals(c.requiredRoleId))role=true;
    if(!role)continue;
    server.execute(()->{if(cfg!=c||System.currentTimeMillis()>=q.expires||!pending.remove(q.connection,q))return; VERIFIED.add(q.connection); q.connection.player.sendSystemMessage(Component.literal("OniCord: Discord ověřen. Můžeš hrát.")); LOG.info("OniCord Auth: verified {}",q.nick);});
    // Optional deletion: bot must have Manage Messages. Failure does not disclose the code in logs.
    request(c,"DELETE","/channels/"+c.channelId+"/messages/"+m.get("id").getAsString()); break;
   }
  }
 }
}
