package cz.onicord.auth;
import com.google.gson.*;
import com.mojang.logging.LogUtils;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;
import java.net.URI;
import java.net.http.*;
import java.nio.file.*;
import java.time.*;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

@Mod("onicordauth")
public class OniCordAuth {
 private static final Logger LOG=LogUtils.getLogger();
 private static final Gson GSON=new GsonBuilder().setPrettyPrinting().create();
 private static final SecureRandom RNG=new SecureRandom();
 private static final Set<ServerGamePacketListenerImpl> VERIFIED=ConcurrentHashMap.newKeySet();
 private final Map<ServerGamePacketListenerImpl,Pending> pending=new ConcurrentHashMap<>();
 private record Anchor(net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level> dimension,double x,double y,double z) {}
 private final Map<UUID,Anchor> anchors=new HashMap<>();
 private final AtomicBoolean busy=new AtomicBoolean();
 private final HttpClient http=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
 private ExecutorService executor;
 private volatile Config cfg;
 private int ticks;
 private volatile long retryAfter=0;
 private volatile long lastWarning=0;
 private final Map<String,Long> handled=new ConcurrentHashMap<>();
 private static Component label(String text,ChatFormatting color){return Component.empty().append(Component.literal("ONICORD ").withStyle(ChatFormatting.AQUA,ChatFormatting.BOLD)).append(Component.literal("| ").withStyle(ChatFormatting.DARK_GRAY)).append(Component.literal(text).withStyle(color));}
 private static void show(Pending q){
  ServerPlayer p=q.connection.player;
  p.sendSystemMessage(label("OVĚŘENÍ ÚČTU",ChatFormatting.WHITE));
  p.sendSystemMessage(Component.literal("Na Discordu v ověřovací místnosti označ @OniCord a napiš:").withStyle(ChatFormatting.GRAY));
  p.sendSystemMessage(Component.literal("@OniCord ").withStyle(ChatFormatting.AQUA).append(Component.literal(q.code).withStyle(ChatFormatting.GREEN,ChatFormatting.BOLD)));
  p.sendSystemMessage(Component.literal("Kód platí 10 minut. Do ověření je hraní zablokováno.").withStyle(ChatFormatting.YELLOW));
 }
 private record Pending(ServerGamePacketListenerImpl connection,String nick,String discord,String code,long expires,Instant created) {}
 private static class Config {
  String botToken="CHANGE_ME", guildId="CHANGE_ME", channelId="CHANGE_ME", botId="CHANGE_ME", requiredRoleId="1415584931232481380";
  Map<String,String> users=new LinkedHashMap<>();
 }
 public OniCordAuth(){ MinecraftForge.EVENT_BUS.register(this); }
 public static boolean allowed(ServerGamePacketListenerImpl listener){return VERIFIED.contains(listener);}
 @SubscribeEvent public void start(ServerStartingEvent event){
  VERIFIED.clear(); pending.clear(); anchors.clear(); handled.clear(); retryAfter=0; lastWarning=0; ticks=0; busy.set(false); executor=Executors.newSingleThreadExecutor();
  Path file=FMLPaths.CONFIGDIR.get().resolve("onicord-auth.json");
  try {
   if(Files.notExists(file)){ Config example=new Config(); example.users.put("tickony","CHANGE_ME"); Files.writeString(file,GSON.toJson(example)); }
   Config c=GSON.fromJson(Files.readString(file),Config.class);
   if(c==null || c.botToken==null || c.botToken.equals("CHANGE_ME") || c.botToken.isBlank()) throw new IllegalArgumentException();
   for(String s:List.of(c.guildId,c.channelId,c.botId,c.requiredRoleId)) if(!s.matches("[0-9]{17,20}")) throw new IllegalArgumentException();
   Map<String,String> clean=new HashMap<>(); Set<String> ids=new HashSet<>();
   for(var e:c.users.entrySet()){
    if(!e.getKey().matches("[A-Za-z0-9_]{3,16}") || !e.getValue().matches("[0-9]{17,20}") || !ids.add(e.getValue()) || clean.put(e.getKey().toLowerCase(Locale.ROOT),e.getValue())!=null) throw new IllegalArgumentException();
   }
   c.users=Map.copyOf(clean); cfg=c; LOG.info("OniCord Auth: loaded {} linked accounts",clean.size());
  }catch(Exception e){cfg=null; LOG.error("OniCord Auth: invalid config; player access disabled. Check config/onicord-auth.json");}
 }
 @SubscribeEvent public void stop(ServerStoppingEvent event){cfg=null; VERIFIED.clear(); pending.clear(); anchors.clear(); if(executor!=null)executor.shutdownNow();}
 @SubscribeEvent public void join(PlayerEvent.PlayerLoggedInEvent event){
  if(!(event.getEntity() instanceof ServerPlayer p))return;
  var connection=p.connection; VERIFIED.remove(connection); Config c=cfg;
  anchors.put(p.getUUID(),new Anchor(p.level().dimension(),p.getX(),p.getY(),p.getZ()));
  if(p.getServer().getPlayerList().isOp(p.getGameProfile())) p.getServer().getPlayerList().deop(p.getGameProfile());
  String nick=p.getGameProfile().getName(); String id=c==null?null:c.users.get(nick.toLowerCase(Locale.ROOT));
  if(id==null){connection.disconnect(Component.literal("OniCord: účet není propojen s Discordem. Kontaktuj administrátora."));return;}
  // Avoid using an unauthenticated player's operator permissions, including after a restart.
  if(p.getServer().getPlayerList().isOp(p.getGameProfile())) {p.getServer().getPlayerList().deop(p.getGameProfile());}
  String code; boolean collision; do {code=String.format(Locale.ROOT,"%08d",RNG.nextInt(100000000)); collision=false; for(Pending q:pending.values())if(q.code.equals(code)){collision=true;break;}}while(collision);
  Pending q=new Pending(connection,nick,id,code,System.currentTimeMillis()+600000,Instant.now()); pending.put(connection,q);
  show(q); LOG.info("OniCord Auth: waiting for Discord verification of {}",nick);
 }
 @SubscribeEvent public void leave(PlayerEvent.PlayerLoggedOutEvent event){if(event.getEntity() instanceof ServerPlayer p){VERIFIED.remove(p.connection);pending.remove(p.connection);anchors.remove(p.getUUID()); if(p.getServer().getPlayerList().isOp(p.getGameProfile()))p.getServer().getPlayerList().deop(p.getGameProfile());}}
 @SubscribeEvent public void tick(TickEvent.ServerTickEvent event){
  if(event.phase!=TickEvent.Phase.END)return;
  for(ServerPlayer p:event.getServer().getPlayerList().getPlayers()){
   if(allowed(p.connection))continue;
   Anchor a=anchors.get(p.getUUID());
   if(a==null)continue;
   p.stopRiding(); p.setDeltaMovement(0,0,0); p.fallDistance=0;
   if(!p.level().dimension().equals(a.dimension())){p.connection.disconnect(Component.literal("OniCord: změna dimenze před ověřením."));continue;}
   if(p.distanceToSqr(a.x(),a.y(),a.z())>0.000001 || p.tickCount%10==0)
    p.connection.teleport(a.x(),a.y(),a.z(),p.getYRot(),p.getXRot());
  }
  for(Pending q:pending.values()) if(System.currentTimeMillis()>=q.expires && pending.remove(q.connection,q))q.connection.disconnect(Component.literal("OniCord: ověření vypršelo. Připoj se znovu."));
  if(++ticks%60!=0 || System.currentTimeMillis()<retryAfter || pending.isEmpty() || cfg==null || !busy.compareAndSet(false,true))return;
  Config c=cfg; MinecraftServer server=event.getServer();
  executor.execute(()->{try{poll(c,server);}catch(Exception e){if(System.currentTimeMillis()-lastWarning>15000){lastWarning=System.currentTimeMillis(); LOG.warn("OniCord Auth: Discord verification unavailable ({})",e.getClass().getSimpleName());}}finally{busy.set(false);}});
 }
 private static boolean locked(net.minecraft.world.entity.Entity e){return e instanceof ServerPlayer p && !allowed(p.connection);}
 @SubscribeEvent public void breakBlock(net.minecraftforge.event.level.BlockEvent.BreakEvent e){if(locked(e.getPlayer()))e.setCanceled(true);}
 @SubscribeEvent public void placeBlock(net.minecraftforge.event.level.BlockEvent.EntityPlaceEvent e){if(locked(e.getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void attack(net.minecraftforge.event.entity.player.AttackEntityEvent e){if(locked(e.getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void rightBlock(net.minecraftforge.event.entity.player.PlayerInteractEvent.RightClickBlock e){if(locked(e.getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void rightItem(net.minecraftforge.event.entity.player.PlayerInteractEvent.RightClickItem e){if(locked(e.getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void leftBlock(net.minecraftforge.event.entity.player.PlayerInteractEvent.LeftClickBlock e){if(locked(e.getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void interact(net.minecraftforge.event.entity.player.PlayerInteractEvent.EntityInteract e){if(locked(e.getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void interactSpecific(net.minecraftforge.event.entity.player.PlayerInteractEvent.EntityInteractSpecific e){if(locked(e.getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void chat(net.minecraftforge.event.ServerChatEvent e){if(locked(e.getPlayer()))e.setCanceled(true);}
 @SubscribeEvent public void command(net.minecraftforge.event.CommandEvent e){if(locked(e.getParseResults().getContext().getSource().getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void pickup(net.minecraftforge.event.entity.player.EntityItemPickupEvent e){if(locked(e.getEntity()))e.setCanceled(true);}
 @SubscribeEvent public void toss(net.minecraftforge.event.entity.item.ItemTossEvent e){if(locked(e.getPlayer())){e.setCanceled(true); e.getPlayer().getInventory().add(e.getEntity().getItem());}}
 private HttpResponse<String> request(Config c,String method,String path)throws Exception{return request(c,method,path,null);}
 private HttpResponse<String> request(Config c,String method,String path,String body)throws Exception{
  var builder=HttpRequest.newBuilder(URI.create("https://discord.com/api/v10"+path)).header("Authorization","Bot "+c.botToken).header("User-Agent","DiscordBot (https://onicord.pro, 0.3.0)").timeout(Duration.ofSeconds(10));
  if(body!=null)builder.header("Content-Type","application/json");
  var result=http.send(builder.method(method,body==null?HttpRequest.BodyPublishers.noBody():HttpRequest.BodyPublishers.ofString(body)).build(),HttpResponse.BodyHandlers.ofString());
  if(result.statusCode()==429){double seconds=5; try{seconds=JsonParser.parseString(result.body()).getAsJsonObject().get("retry_after").getAsDouble();}catch(Exception ignored){} retryAfter=System.currentTimeMillis()+Math.max(1000,(long)(seconds*1000)+500); LOG.warn("OniCord Auth: Discord rate limit; retry scheduled");}
  return result;
 }
 private void feedback(Config c,MinecraftServer server,Pending q,String message){
  server.execute(()->{if(pending.get(q.connection)==q)q.connection.player.sendSystemMessage(label(message,ChatFormatting.RED));});
 }
 private void reply(Config c,String messageId,String message)throws Exception{
  if(System.currentTimeMillis()<retryAfter)return;
  JsonObject body=new JsonObject(); body.addProperty("content",message);
  JsonObject ref=new JsonObject();ref.addProperty("message_id",messageId);ref.addProperty("fail_if_not_exists",false);body.add("message_reference",ref);
  JsonObject mentions=new JsonObject();mentions.add("parse",new JsonArray());mentions.addProperty("replied_user",false);body.add("allowed_mentions",mentions);
  var r=request(c,"POST","/channels/"+c.channelId+"/messages",body.toString());
  if(r.statusCode()!=200 && r.statusCode()!=201)LOG.warn("OniCord Auth: Discord reply HTTP {}",r.statusCode());
 }
 private void poll(Config c,MinecraftServer server)throws Exception{
  long now=System.currentTimeMillis(); handled.entrySet().removeIf(e->e.getValue()<now-900000);
  Instant earliest=pending.values().stream().map(Pending::created).min(Instant::compareTo).orElse(Instant.now()).minusSeconds(10);
  String before="";
  for(int page=0;page<10 && !pending.isEmpty();page++){
   if(System.currentTimeMillis()<retryAfter)return;
   var response=request(c,"GET","/channels/"+c.channelId+"/messages?limit=100"+(before.isEmpty()?"":"&before="+before));
   if(response.statusCode()!=200){if(now-lastWarning>15000){lastWarning=now;LOG.warn("OniCord Auth: reading verification channel HTTP {} (401 token, 403 permissions, 404 channel)",response.statusCode());}return;}
   JsonArray messages=JsonParser.parseString(response.body()).getAsJsonArray();
   if(messages.isEmpty())return;
   boolean old=false;
   for(JsonElement entry:messages){
    if(System.currentTimeMillis()<retryAfter)return;
    JsonObject m=entry.getAsJsonObject(); String mid=m.get("id").getAsString(); before=mid;
    Instant sent=OffsetDateTime.parse(m.get("timestamp").getAsString()).toInstant(); if(sent.isBefore(earliest)){old=true;continue;}
    if(handled.containsKey(mid))continue;
    JsonObject author=m.getAsJsonObject("author"); if(author.has("bot")&&author.get("bot").getAsBoolean())continue;
    String id=author.get("id").getAsString(); String body=m.has("content")?m.get("content").getAsString().trim():"";
    // Accept real Discord mentions, including the legacy nickname mention syntax.
    String prefix="<@"+c.botId+">", alt="<@!"+c.botId+">";
    boolean mention=body.startsWith(prefix)||body.startsWith(alt);
    String code=mention?body.substring(body.indexOf('>')+1).trim():"";
    Pending own=pending.values().stream().filter(q->q.discord.equals(id)).findFirst().orElse(null);
    if(!mention){if(own!=null && body.matches("[0-9]{8}")){handled.put(mid,now);feedback(c,server,own,"Označ skutečného bota @OniCord před kódem.");reply(c,mid,"Označ @OniCord a přidej svůj ověřovací kód.");}continue;}
    if(own==null){handled.put(mid,now);reply(c,mid,"Pro tento Discord účet není aktivní ověření. Zkontroluj propojení s admin týmem.");continue;}
    if(!code.matches("[0-9]{8}") || !own.code.equals(code) || sent.isBefore(own.created.minusSeconds(10)) || System.currentTimeMillis()>=own.expires){handled.put(mid,now);feedback(c,server,own,"Kód nesouhlasí nebo vypršel. Použij aktuální kód z Minecraftu.");reply(c,mid,"Kód nesouhlasí nebo vypršel. Použij aktuální kód z Minecraftu.");continue;}
    var member=request(c,"GET","/guilds/"+c.guildId+"/members/"+id);
    if(member.statusCode()!=200){LOG.warn("OniCord Auth: membership lookup for {} HTTP {}",own.nick,member.statusCode()); if(member.statusCode()==404){handled.put(mid,now);feedback(c,server,own,"Discord účet není členem serveru.");reply(c,mid,"Nejsi členem požadovaného Discord serveru.");}else if(member.statusCode()!=429){feedback(c,server,own,"Discord API neodpovědělo správně (HTTP "+member.statusCode()+"). Kontaktuj admina.");}continue;}
    boolean role=false; for(JsonElement r:JsonParser.parseString(member.body()).getAsJsonObject().getAsJsonArray("roles"))if(r.getAsString().equals(c.requiredRoleId))role=true;
    if(!role){handled.put(mid,now);LOG.info("OniCord Auth: required role missing for {}",own.nick);feedback(c,server,own,"Chybí požadovaná Discord role.");reply(c,mid,"Chybí požadovaná role. Po získání role odešli kód znovu.");continue;}
    handled.put(mid,now);
    CompletableFuture<Boolean> accepted=new CompletableFuture<>();
    server.execute(()->{if(cfg!=c||System.currentTimeMillis()>=own.expires||!pending.remove(own.connection,own)){accepted.complete(false);return;} VERIFIED.add(own.connection); anchors.remove(own.connection.player.getUUID()); own.connection.player.sendSystemMessage(label("Úspěšně ověřeno! Vítej na OniCordu.",ChatFormatting.GREEN)); LOG.info("OniCord Auth: verified {}",own.nick); accepted.complete(true);});
    if(accepted.get(10,TimeUnit.SECONDS)){reply(c,mid,"✅ Ověření proběhlo úspěšně. Můžeš hrát!"); if(System.currentTimeMillis()>=retryAfter){var deletion=request(c,"DELETE","/channels/"+c.channelId+"/messages/"+mid);if(deletion.statusCode()!=204 && deletion.statusCode()!=404)LOG.warn("OniCord Auth: message deletion HTTP {}",deletion.statusCode());}}
   }
   if(old||messages.size()<100)return;
  }
 }
}
